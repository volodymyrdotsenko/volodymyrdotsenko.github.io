<head>
  <!-- Required meta tags -->
<!--   <meta http-equiv='refresh' content='9; url=https://rayton.com.ua'>
 -->
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta name="discrption" content="parallax one page" />
  <meta name="keyword"

    content=""/>

  <!--  Title -->
  <title>Продажа, доставка и установка солнечных панелей для дома и бизнеса - Rayton</title>

  <!-- Font Google -->
<style>/*! CSS Used fontfaces */
@font-face{font-family:'Montserrat';font-style:normal;font-weight:400;font-display:swap;src:url(https://fonts.gstatic.com/s/montserrat/v15/JTUSjIg1_i6t8kCHKm459WRhyyTh89ZNpQ.woff2) format('woff2');unicode-range:U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;}
@font-face{font-family:'Montserrat';font-style:normal;font-weight:400;font-display:swap;src:url(https://fonts.gstatic.com/s/montserrat/v15/JTUSjIg1_i6t8kCHKm459W1hyyTh89ZNpQ.woff2) format('woff2');unicode-range:U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;}
@font-face{font-family:'Montserrat';font-style:normal;font-weight:400;font-display:swap;src:url(https://fonts.gstatic.com/s/montserrat/v15/JTUSjIg1_i6t8kCHKm459WZhyyTh89ZNpQ.woff2) format('woff2');unicode-range:U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;}
@font-face{font-family:'Montserrat';font-style:normal;font-weight:400;font-display:swap;src:url(https://fonts.gstatic.com/s/montserrat/v15/JTUSjIg1_i6t8kCHKm459WdhyyTh89ZNpQ.woff2) format('woff2');unicode-range:U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;}
@font-face{font-family:'Montserrat';font-style:normal;font-weight:400;font-display:swap;src:url(https://fonts.gstatic.com/s/montserrat/v15/JTUSjIg1_i6t8kCHKm459WlhyyTh89Y.woff2) format('woff2');unicode-range:U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;}
@font-face{font-family:'Montserrat';font-style:normal;font-weight:500;font-display:swap;src:url(https://fonts.gstatic.com/s/montserrat/v15/JTURjIg1_i6t8kCHKm45_ZpC3gTD_vx3rCubqg.woff2) format('woff2');unicode-range:U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;}
@font-face{font-family:'Montserrat';font-style:normal;font-weight:500;font-display:swap;src:url(https://fonts.gstatic.com/s/montserrat/v15/JTURjIg1_i6t8kCHKm45_ZpC3g3D_vx3rCubqg.woff2) format('woff2');unicode-range:U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;}
@font-face{font-family:'Montserrat';font-style:normal;font-weight:500;font-display:swap;src:url(https://fonts.gstatic.com/s/montserrat/v15/JTURjIg1_i6t8kCHKm45_ZpC3gbD_vx3rCubqg.woff2) format('woff2');unicode-range:U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;}
@font-face{font-family:'Montserrat';font-style:normal;font-weight:500;font-display:swap;src:url(https://fonts.gstatic.com/s/montserrat/v15/JTURjIg1_i6t8kCHKm45_ZpC3gfD_vx3rCubqg.woff2) format('woff2');unicode-range:U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;}
@font-face{font-family:'Montserrat';font-style:normal;font-weight:500;font-display:swap;src:url(https://fonts.gstatic.com/s/montserrat/v15/JTURjIg1_i6t8kCHKm45_ZpC3gnD_vx3rCs.woff2) format('woff2');unicode-range:U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;}
@font-face{font-family:'Montserrat';font-style:normal;font-weight:600;font-display:swap;src:url(https://fonts.gstatic.com/s/montserrat/v15/JTURjIg1_i6t8kCHKm45_bZF3gTD_vx3rCubqg.woff2) format('woff2');unicode-range:U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;}
@font-face{font-family:'Montserrat';font-style:normal;font-weight:600;font-display:swap;src:url(https://fonts.gstatic.com/s/montserrat/v15/JTURjIg1_i6t8kCHKm45_bZF3g3D_vx3rCubqg.woff2) format('woff2');unicode-range:U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;}
@font-face{font-family:'Montserrat';font-style:normal;font-weight:600;font-display:swap;src:url(https://fonts.gstatic.com/s/montserrat/v15/JTURjIg1_i6t8kCHKm45_bZF3gbD_vx3rCubqg.woff2) format('woff2');unicode-range:U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;}
@font-face{font-family:'Montserrat';font-style:normal;font-weight:600;font-display:swap;src:url(https://fonts.gstatic.com/s/montserrat/v15/JTURjIg1_i6t8kCHKm45_bZF3gfD_vx3rCubqg.woff2) format('woff2');unicode-range:U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;}
@font-face{font-family:'Montserrat';font-style:normal;font-weight:600;font-display:swap;src:url(https://fonts.gstatic.com/s/montserrat/v15/JTURjIg1_i6t8kCHKm45_bZF3gnD_vx3rCs.woff2) format('woff2');unicode-range:U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;}
@font-face{font-family:'Montserrat';font-style:normal;font-weight:700;font-display:swap;src:url(https://fonts.gstatic.com/s/montserrat/v15/JTURjIg1_i6t8kCHKm45_dJE3gTD_vx3rCubqg.woff2) format('woff2');unicode-range:U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;}
@font-face{font-family:'Montserrat';font-style:normal;font-weight:700;font-display:swap;src:url(https://fonts.gstatic.com/s/montserrat/v15/JTURjIg1_i6t8kCHKm45_dJE3g3D_vx3rCubqg.woff2) format('woff2');unicode-range:U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;}
@font-face{font-family:'Montserrat';font-style:normal;font-weight:700;font-display:swap;src:url(https://fonts.gstatic.com/s/montserrat/v15/JTURjIg1_i6t8kCHKm45_dJE3gbD_vx3rCubqg.woff2) format('woff2');unicode-range:U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;}
@font-face{font-family:'Montserrat';font-style:normal;font-weight:700;font-display:swap;src:url(https://fonts.gstatic.com/s/montserrat/v15/JTURjIg1_i6t8kCHKm45_dJE3gfD_vx3rCubqg.woff2) format('woff2');unicode-range:U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;}
@font-face{font-family:'Montserrat';font-style:normal;font-weight:700;font-display:swap;src:url(https://fonts.gstatic.com/s/montserrat/v15/JTURjIg1_i6t8kCHKm45_dJE3gnD_vx3rCs.woff2) format('woff2');unicode-range:U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;}
@font-face{font-family:'Montserrat';font-style:normal;font-weight:800;font-display:swap;src:url(https://fonts.gstatic.com/s/montserrat/v15/JTURjIg1_i6t8kCHKm45_c5H3gTD_vx3rCubqg.woff2) format('woff2');unicode-range:U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;}
@font-face{font-family:'Montserrat';font-style:normal;font-weight:800;font-display:swap;src:url(https://fonts.gstatic.com/s/montserrat/v15/JTURjIg1_i6t8kCHKm45_c5H3g3D_vx3rCubqg.woff2) format('woff2');unicode-range:U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;}
@font-face{font-family:'Montserrat';font-style:normal;font-weight:800;font-display:swap;src:url(https://fonts.gstatic.com/s/montserrat/v15/JTURjIg1_i6t8kCHKm45_c5H3gbD_vx3rCubqg.woff2) format('woff2');unicode-range:U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;}
@font-face{font-family:'Montserrat';font-style:normal;font-weight:800;font-display:swap;src:url(https://fonts.gstatic.com/s/montserrat/v15/JTURjIg1_i6t8kCHKm45_c5H3gfD_vx3rCubqg.woff2) format('woff2');unicode-range:U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;}
@font-face{font-family:'Montserrat';font-style:normal;font-weight:800;font-display:swap;src:url(https://fonts.gstatic.com/s/montserrat/v15/JTURjIg1_i6t8kCHKm45_c5H3gnD_vx3rCs.woff2) format('woff2');unicode-range:U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;}</style>


  <link rel=" shortcut icon" href="https://rayton.com.ua/assets/img/favicon.ico" type="image/x-icon" />
  <link rel="icon" href="https://rayton.com.ua/assets/img/favicon.ico" type="image/x-icon" />

  <!-- custom styles (optional) -->
  
  <link href="https://rayton.com.ua/assets/css/plugins.css" rel=" stylesheet" />
  <link href="https://rayton.com.ua/assets/css/one_stylesheet.css" rel=" stylesheet" />
  <meta name="google-site-verification" content="rSSDWkn-LGEtW4QkSe2Z7aZXgtBhL9AtUIOupF6iSvg" />
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NV2SF2N');</script>
<!-- End Google Tag Manager -->
</head>
<body class="v-light hamburger-menu dsn-effect-scroll dsn-ajax" data-dsn-mousemove="true">
  <div data-dsn-temp="light"></div>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NV2SF2N"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NV2SF2N"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

  <!-- Nav Bar -->
    <div class="dsn-nav-bar">
        <div class=" site-header">
            <div class="extend-container">
                <div class="inner-header">
                    <div class="main-logo">
                        <a href="https://rayton.com.ua/">
                           
                            <img class="light-logo" src="https://rayton.com.ua/assets/img/logo.png" alt="" />
                        </a>
                    </div>
                </div>
                 <nav class=" accent-menu main-navigation">
                    <ul class="extend-container">
                        <!--<li><a href="https://rayton.com.ua/one-page-3.html#">Дилерам</a></li>-->
                        <li><a href="https://rayton.com.ua/about us.html"><strong>О нас</strong></a></li>
                        <li><a href="https://rayton.com.ua/rayton_home/"><strong><img src="https://rayton.com.ua/assets/img/logo.png"
                                                    alt="" style="width: 21%">  Home |  </strong><p style="color: #444446;font-size: small;display:inline-block;"> для домовладений</p></a></li>
                                            <li><a href="https://rayton.com.ua/rayton_business/"><strong><img src="https://rayton.com.ua/assets/img/logo.png"
                                                    alt="" style="width: 21%">  Business |  </strong><p style="color: #444446;font-size: small;display:inline-block;"> для и предприятий</p></a></li>
                                                    <li><a href="https://rayton.com.ua/rayton_partner/"><strong><img src="https://rayton.com.ua/assets/img/logo.png"
                                                    alt="" style="width: 21%">  Partner |  </strong><p style="color: #444446;font-size: small;display:inline-block;"> для диллеров</p></a></li>
                                                    <li><a href="https://rayton.com.ua/portfolio.html"><strong><img src="https://rayton.com.ua/assets/img/logo.png"
                                                    alt="" style="width: 21%">  Portfolio |  </strong><p style="color: #444446;font-size: small;display:inline-block;"> топ наших работ</p></a></li>
                                            <li><a href="https://rayton.com.ua/blog.html"><strong>Блог |  </strong><p style="color: #444446;font-size: small;display:inline-block;"> новости из мира солнечной энергии</p></a></li>
                                            <li><a href="https://rayton.com.ua/q&a.html"><strong>Вопросы и ответы</strong></a></li>

                                            <!--<li><a href="https://rayton.com.ua/one-page-3.html#">Городу</a></li>
                                            <li><a href="https://rayton.com.ua/one-page-3.html#">Инвесторам</a></li>-->
                                            <li><a href="https://rayton.com.ua/rayton-contact.html"><strong>Контакты</strong></a>
                                            </li>
                    </ul>
                </nav>
            </div>
        </div>
        <div class="header-top header-top-hamburger">
            <div class="header-container">
                <div class="logo main-logo">
                    <a href="https://rayton.com.ua/">
                        <img class="light-logo" src="https://rayton.com.ua/assets/img/logo.png" alt="" />
                    </a>
                </div>

                <div class="menu-icon" data-dsn="parallax" data-dsn-move="5">
                    <div class="icon-m">
                        <i class="menu-icon-close fas fa-times"></i>
                        <span class="menu-icon__line menu-icon__line-left"></span>
                        <span class="menu-icon__line"></span>
                        <span class="menu-icon__line menu-icon__line-right"></span>
                    </div>

                    <div class="text-menu" style="color: #fff">
                        <div class="text-button" style="color: #212121">Меню</div>
                        <div class="text-open" style="color: #212121">Открыть меню</div>
                        <div class="text-close" style="color: #5a5b5b">Закрыть</div>
                    </div>
                </div>

                <div class="nav">
                    <div class="inner">
                        <div class="nav__content" style="background-color: #f6bc33">

                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <!-- End Nav Bar -->
  <main class="main-root">
    <div id="dsn-scrollbar">
      <header style="background-color: #f6ba33">
        <!-- <div class="box-seat section-margin">
                        <div class="container-fluid">
                            <div class="inner-img" data-dsn-grid="move-up">
                                <img src="https://rayton.com.ua/assets/img/Home.png" alt="">
                            </div>
                            <div class="pro-text" data-dsn-grid="move-section">
                                <img src="https://rayton.com.ua/assets/img/ryton_logo_blk.png" alt="" ><h3 data-dsn-animate="text"> Home</h3>
                                <p data-dsn-animate="text">Подберем и установим подходящую вашим потребностям солнечную электростанцию. Также дадим дополнительную гарантию от Rayton и будем следить за тем, чтобы все работало как надо</p>
                            </div>
                        </div>
                    </div>
                    <div class="container intro-project section-margin">
                        <div class="intro-text">
                            <div class="title-cover" data-dsn-grid="move-section" data-dsn-opacity="0.1"
                                data-dsn-duration="170%" data-dsn-move="0%">
                                Rayton Home
                            </div>
                            <div class="inner">
                                <h2 data-dsn-animate="text">Мы не будем нагружать вас сложными терминами,</h2>
                                <p data-dsn-animate="up"> очередной раз рассказывать про «зеленый тариф» и продавать выгодное нам оборудование. У нас более простые цели — мы хотим сделать солнечную энергетику настолько доступной, как это стало с подключением интернета.<br>Вы оставили заявку, наши специалисты связались с вами для подбора оптимального решения, мы привезли и установили оборудование, проверили его работу — и дело сделано.</p>
                                <ul class="mt-20" data-dsn-animate="up">
                                    <li>              <img src="https://rayton.com.ua/assets/img/rayt_lines_1.png" style="position: absolute; max-width: 50%"></li>
                                    
                                </ul>

                            </div>
                        </div>
                    </div> -->

      </header>

      <div class="wrapper">
        <div class="box-seat box-seat-full section-margin" style="margin-bottom: 5%">
                        <div class="container" style="
                        padding: ;
    font-size: xx-large;
    font-weight: 700;
    padding-top: 10vh;
    background-color: #f6ba33;
">

<?php
if($_POST) {
// ваш секретный ключ
$secret = '6Ld0WNccAAAAACGgs-lWv7DDFLv21qxQOItV_tqD';
// однократное включение файла autoload.php (клиентская библиотека reCAPTCHA PHP)
require_once (dirname(__FILE__).'/recaptcha/autoload.php');
// если в массиве $_POST существует ключ g-recaptcha-response, то...
if (isset($_POST['g-recaptcha-response'])) {
  // создать экземпляр службы recaptcha, используя секретный ключ
  $recaptcha = new \ReCaptcha\ReCaptcha($secret);
  // получить результат проверки кода recaptcha
  $resp = $recaptcha->verify($_POST['g-recaptcha-response'], $_SERVER['REMOTE_ADDR']);
  // если результат положительный, то...
  if ($resp->isSuccess()){
    // действия, если код captcha прошёл проверку
    
    $visitor_name = "";
    $email_title = "";
    // $visitor_subject = "Новый ответ на форму";
    $visitor_email = "";
    $visitor_message = "";
     
    if(isset($_POST['visitor_name'])) {
      $visitor_name = filter_var($_POST['visitor_name'], FILTER_SANITIZE_STRING);
    }
     
    if(isset($_POST['visitor_email'])) {
        $visitor_email = str_replace(array("\r", "\n", "%0a", "%0d"), '', $_POST['visitor_email']);
        $visitor_email = filter_var($visitor_email, FILTER_VALIDATE_EMAIL);
    }
     if(isset($_POST['email_title'])) {
        $email_title = filter_var($_POST['email_title'], FILTER_SANITIZE_STRING);
    }
    if(isset($_POST['visitor_message'])) {
        $visitor_message = htmlspecialchars($_POST['visitor_message']);
    }
    if(isset($_POST['visitor_email'])){
        $recipient = "info@rayton.com.ua";
    }
     
    $headers  = 'MIME-Version: 1.0' . "\r\n"
    .'Content-type: text/html; charset=utf-8' . "\r\n"
    .'From: ' . $visitor_email . "\r\n";
     
    if(mail($recipient, $email_title, $visitor_message, $headers)) {
        echo "<p>Поздравляем, $visitor_name, ваш запрос успешно отправлен! <br> Наши специалисты свяжутся с вами в ближайшее время.</p>";
    } else {
        echo '<p>We are sorry but the email did not go through.</p>';
    }
     
} else {
    echo '<p>Something went wrong</p>';

  } else {
    // иначе передать ошибку
    $errors = $resp->getErrorCodes();
    $data['error-captcha']=$errors;
    $data['msg']='Код капчи не прошёл проверку на сервере';
    $data['result']='error';
  }

} else {
  //ошибка, не существует ассоциативный массив $_POST["send-message"]
  $data['result']='error';
}
}
 
?></div></div></div>           <footer class="footer">
                <div class="container">
                    <div class="footer-links p-relative">
                        
                        <div class="row">

                            <div class="col-sm-3 dsn-col-footer">
                                <div class="footer-block">
                                    
                                    <div class="footer-block col-menu">
                                    <nav>
                                        <ul>
                                            <!--<li><a href="https://rayton.com.ua/one-page-3.html#">Дилерам</a></li>-->
                                            <li><a href="https://rayton.com.ua/rayton_home/"><strong>Rayton Home</strong></a></li>
                                            <li><a href="https://rayton.com.ua/rayton_business/"><strong>Rayton Business</strong></a></li>
                                            <li><a href="https://rayton.com.ua/rayton_partner/"><strong>Rayton Partner</strong></a></li>
                                            <li><a href="https://rayton.com.ua/portfolio.html"><strong>Портфолио</strong></a></li>
                                            
                                            
                                        </ul>
                                    </nav>
                                </div>

                                    
                                </div>
                            </div>
 <div class="col-sm-3 dsn-col-footer">
                                <div class="footer-block">
                                    
                                    <div class="footer-block col-menu">
                                    <nav>
                                        <ul>
                                             <li><a href="https://rayton.com.ua/q&a.html"><strong>Вопросы и ответы</strong></a></li>
                                            <li><a href="https://rayton.com.ua/about us.html"><strong>О нас</strong></a></li>
                                            <li><a href="https://rayton.com.ua/blog.html"><strong>Блог</strong></a></li>

                                            <!--<li><a href="https://rayton.com.ua/one-page-3.html#">Городу</a></li>
                                            <li><a href="https://rayton.com.ua/one-page-3.html#">Инвесторам</a></li>-->
                                            <li><a href="https://rayton.com.ua/rayton-contact.html"><strong>Контакты</strong></a></li>
                                            
                                            
                                        </ul>
                                    </nav>
                                </div>

                                    
                                </div>
                            </div>



                           

                            <div class="col-md-6 dsn-col-footer" style="padding:0px">

                                <div class="footer-block col-contact">
                                    
                                    <p>Наш офис<span>:</span><strong>Киев, ул. Пшеничная 8</strong></p>
                                    <p>Звоните нам <span>:</span> <a href="https://rayton.com.ua/tel:+380443002101"><strong>(044) 300-21-01</strong></a></p>                                    
                                    
                                    <p class="over-hidden">Пишите на почту<span>:</span><a class="link-hover"
                                            data-hover-text=" sales@rayton.com.ua" href="mailto:sales@rayton.com.ua"><strong>sales@rayton.com.ua</strong></a>
                                    </p>
                                </div>
                            </div>

                            
                        </div>
                        <!-- <div class="footer-logo">
                                        <img src="https://rayton.com.ua/assets/img/logo.png" style="max-width: 160px;" alt="">
                                         <a href="https://www.facebook.com/Rayton-110232517357237/"><i class="fab fa-facebook-f" style="
    font-size: xx-large;
    margin: 20px;
"></i></a>
                                            <a href="https://www.youtube.com/channel/UCEyFiOQglpKZaTb-ROdjUeA/"><i class="fab fa-youtube"style="
    font-size: xx-large;
    margin: 20px;
"></i></a>
                                            <a href="https://www.instagram.com/rayton_sun/"><i class="fab fa-instagram"style="
    font-size: xx-large;
    margin: 20px;
"></i></a>


                                    </div> -->
                    </div>

                    <div class="copyright">
                        <div class="text-center">
                            <div class="footer-logo">
                                        
                                         <div class="footer-social">
                                            <a href="https://rayton.com.ua/">
                                                <img src="https://rayton.com.ua/assets/img/logo.png" style="max-width: 160px;" alt="">
                                            </a>

                                        
                                            <a href="https://www.facebook.com/Rayton-110232517357237/"><i class="fab fa-facebook-f"></i></a>
                                            <a href="https://www.youtube.com/channel/UCEyFiOQglpKZaTb-ROdjUeA/"><i class="fab fa-youtube"></i></a>
                                            <a href="https://www.instagram.com/rayton_sun/"><i class="fab fa-instagram"></i></a>
                                            

                 

                                    </div>


                                    </div>
                            <p>© 2021 Rayton - Future Energy Experts</p>
                            <div class="copright-text over-hidden">Designed by <a class="link-hover"
                                     href="https://rayton.com.ua" target="_blank">V</a>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </main>

    <!-- Wait Loader -->
    <div class="wait-loader">
        <div class="loader-inner">
            <div class="loader-circle">
                <div class="loader-layer"></div>
            </div>
        </div>
    </div>
    <!-- // Wait Loader -->


    <!-- Optional JavaScript -->
    <script src="https://rayton.com.ua/assets/js/jquery-3.6.0.min.js"></script>
    <script src="https://rayton.com.ua/assets/js/plugins.js"></script>
    <script src="https://rayton.com.ua/assets/js/dsn-grid.js"></script>
    <script src="https://rayton.com.ua/assets/js/custom.js"></script>
</body>
