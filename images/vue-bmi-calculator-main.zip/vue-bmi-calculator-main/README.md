# vue-bmi-calculator

Calculate your body mass index (BMI) with this simple Vue app. This app was created to learn more about Vue and state in Vue.

![screenshot displaying the app](./app-screenshot.png)
